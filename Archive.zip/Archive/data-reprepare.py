import os
import numpy as np
import pandas as pd
np.set_printoptions(suppress=True)
import random
import csv

def data_prepare(train_path, test_path):
    train_data = pd.read_csv (train_path, sep=',').values
    test_data = pd.read_csv(test_path,sep=',').values
    #print(train_data)
    train_row,train_col = train_data.shape
    test_row,test_col = test_data.shape
    train_data_after_prepare = np.zeros((train_row,13))
    test_data_after_prepare = np.zeros((test_row,13))

    for i in range(train_row):
        opponent=1
        myself = 6
        train_data_after_prepare[i][0]=int(i)
        for j in range(1,train_col):
            if(train_data[i][j]==-1):
                train_data_after_prepare[i][opponent]=int(j)
                opponent += 1
            if(train_data[i][j]==1):
                train_data_after_prepare[i][myself]=int(j)
                myself += 1
        if(train_data[i][0]==1):
            train_data_after_prepare[i][11] = int(train_data[i][0])
        if(train_data[i][0]==-1):
            train_data_after_prepare[i][11] = 0
        train_data_after_prepare[i][12] = int(random.randint(0,3000000))

    #print(train_data_after_prepare)
    #train_data_after_prepare.to_csv(os.getcwd()+'/train_after_prepare.csv',encoding='utf-8')
    np.savetxt('new.csv', train_data_after_prepare, delimiter=',',fmt='%d')



if __name__ == '__main__':
    data_prepare(os.getcwd() + '/dota2Train.csv', os.getcwd() + '/dota2Test.csv')
